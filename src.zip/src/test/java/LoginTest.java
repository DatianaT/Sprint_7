import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.example.courier.CourierClient;
import org.example.models.Courier;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.example.courier.CourierGenerator.randomCourier;
import static org.example.models.CourierCreds.fromCourier;
import static org.junit.Assert.assertEquals;

public class LoginTest {
        private static final String BASE_URL = "https://qa-scooter.praktikum-services.ru/";
        private String id;

        @Before
        public void setUp(){
            RestAssured.baseURI = BASE_URL;
        }

        @Test
        public void loginCourier(){
            Courier courier = randomCourier();
            CourierClient courierClient = new CourierClient();

            Response loginResponse = courierClient.login(fromCourier(courier));
            id = loginResponse.path("id");

            assertEquals("Неверный статус код", HttpStatus.SC_OK, loginResponse.statusCode());
        }

        @After
        public void tearDown(){
            //courierClient.delete(id);
        }




}
