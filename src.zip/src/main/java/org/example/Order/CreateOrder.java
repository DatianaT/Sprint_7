package org.example.Order;

public class CreateOrder {
    private static final String Order_URL = "/api/v1/orders";
    private String firstName;
    private String lastName;
    private String adress;
    private String metroStation;
    private String phone;
    private int rentTime;
    private String deliveryDate;
    private String comment;
    public String[] color;

    public String getFirstName() {
        return firstName;
    }

    public CreateOrder setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public String getLastName() {
        return lastName;
    }

    public CreateOrder setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public String getAdress() {
        return adress;
    }

    public CreateOrder setAdress(String adress) {
        this.adress = adress;
        return this;
    }

    public String getMetroStation() {
        return metroStation;
    }

    public CreateOrder setMetroStation(String metroStation) {
        this.metroStation = metroStation;
        return this;
    }

    public String getPhone() {
        return phone;
    }

    public CreateOrder setPhone(String phone) {
        this.phone = phone;
        return this;
    }

    public int getRentTime() {
        return rentTime;
    }

    public CreateOrder setRentTime(int rentTime) {
        this.rentTime = rentTime;
        return this;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public CreateOrder setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
        return this;
    }

    public String getComment() {
        return comment;
    }

    public CreateOrder setComment(String comment) {
        this.comment = comment;
        return this;
    }

    public String[] getColor() {
        return color;
    }

    public CreateOrder setColor(String[] color) {
        this.color = color;
        return this;
    }
}
