package org.example.courier;

import io.qameta.allure.Step;
import io.restassured.response.Response;
import org.example.models.Courier;
import org.example.models.CourierCreds;

import static io.restassured.RestAssured.given;

public class CourierClient {
    private static final String COURIER_URL = "/api/v1/courier";
    private static final String COURIER_LOGIN_URL = "/api/v1/courier/login";
    @Step("Создание курьера {courier}")
    public Response create(Courier courier){
        return given()
                .header("Content-type", "application/json")
                .and()
                .body(courier)
                .when()
                .post(COURIER_URL);
    }
    @Step("Авторизация курьера с кредами {courierCred}")
    public Response login(CourierCreds courierCred) {
        return given()
                .header("Content-type", "application/json")
                .and()
                .body(courierCred)
                .when()
                .post(COURIER_LOGIN_URL);
    }
}
