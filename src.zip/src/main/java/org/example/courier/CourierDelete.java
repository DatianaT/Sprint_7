package org.example.courier;

public class CourierDelete {
}
