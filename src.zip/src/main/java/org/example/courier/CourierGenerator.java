package org.example.courier;
import org.example.models.Courier;

import static utils.Utils.randomString;

public class CourierGenerator {
 public static Courier randomCourier(){
     return new Courier()
             .withLogin(randomString(8))
             .withPassword(randomString(16))
             .withNickName(randomString(10));
 }
    public static Courier randomCourierWitoutLigin(){
        return new Courier()
                .withPassword(randomString(16))
                .withNickName(randomString(10));
    }


}

