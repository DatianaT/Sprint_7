package org.example.constant;

public class Const {
    private static String BASE_URL = "https://qa-scooter.praktikum-services.ru/";

    private static final String COURIER_URL = "/api/v1/courier";
    private static final String COURIER_LOGIN_URL = "/api/v1/courier/login";
    private static final String DELETE_COURIER = "/api/v1/courier/:id";

    private static final String ORDERS_COUNT = "/api/v1/courier/:id/ordersCount";

    private static final String ORDER_URL = "/api/v1/orders";
    private static final String ORDER_FINISH = "/api/v1/orders/finish/:id";
    private static final String ORDER_CANCEL = "/api/v1/orders/cancel";
    private static final String GET_ORDER_LIST = "/api/v1/orders";
    private static final String GET_ORDER_TRACK = "/api/v1/orders/track";
    private static final String ACCEPT_ORDER = "/api/v1/orders/accept/:id";

    private static final String PING_SERVER = "/api/v1/ping";
    private static final String SEARCH_METRO_STATION = "/api/v1/stations/search";


}
