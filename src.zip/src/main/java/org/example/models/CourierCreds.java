package org.example.models;

public class CourierCreds {
    private String login;
    private String password;

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public CourierCreds(String login, String password) {
        this.login = login;
        this.password = password;
    }

    public static CourierCreds fromCourier(Courier courier){
        return new CourierCreds(courier.getLogin(), courier.getPasswordHash());
    }

    @Override
    public String toString() {
        return "CourierCred{" +
                "login='" + login + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
